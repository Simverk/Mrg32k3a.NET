# RngStreams verification vectors

Deterministic test vectors generated from the MRG32k3a RngStreams package
(L'Ecuyer, 2001-08-14). `vectors.json` holds the expected outputs and
generator states for each case.

## Contents

- `vectors.json` — 40 deterministic cases (see schema below).
- `vectors.json.sha256` — integrity hash. Verify with:
  `sha256sum -c vectors.json.sha256`

## Provenance

- Reference: RngStreams C interface, 14 August 2001 (`RngStream.c`).
- Generator: `./rngstream-kat --out vectors.json --n 1000`
- Compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, `-std=c99 -O2`
- `vectors.json` sha256: see `vectors.json.sha256`.

## Schema

Top level: `{ "meta": {...}, "cases": [...] }`.

- `u01_sequence`: `initial_cg` (6 uints), then `draws[]` with
  `cg` (post-draw `GetState`), `u01` (`%.17g`), `u01_bits` (hex IEEE-754
  uint64, e.g. `"0x3fc041e683b58b4b"`), `u01_hex` (`%a`).
  Rule: set the stream to `initial_cg`; each draw must match
  `u01_bits` exactly and advance `Cg` to `cg`.
- `randint_sequence`: same states plus integer `value` for `RandInt(lo,hi)`,
  with `antithetic` and `increased_precis` flags recorded.
  Note: with `increased_precis=1` each `RandInt` consumes two underlying
  draws; with `0` it consumes one.
- Combined-flag cases: `both_on_200` (`u01_sequence` with antithetic=1
  and increased_precis=1, i.e. the `U01d` antithetic branch) and
  `randint_1_10_both_200` (same flags through `RandInt`).
- `state_check`: `actual` vs `expected` (6 uints) with `match: true`.
  Covers 2^127 stream spacing, `AdvanceState`, substream resets, known
  `.res` states.
- `double_check`: `value` vs `expected` (final `39.697547` replicates
  `testRngStream.c`).
- `checksum`: informational long-run sums (100k-draw) in the
  `testRngStream` flow, plus `checksum_g2_100k_incprec` (test2 flow:
  100k IncreasedPrecis draws from stream start; full bits, prints
  `50098.2241`); assert exact `value_bits` match.
- `driver_trace` (`testRngStream_driver`): ordered walk of
  `testRngStream.c` — one step per op (`create_stream`, `advance_state`,
  resets, `set_antithetic`/`increased_precis` as steps, `rand_u01`,
  `loop` with unscaled `block_total`, structured `combine`
  `{target, source, divide_then_add, operand + bits}`). Every step carries
  post-step `cg_after` (stream steps) and all accumulators (`sum`, `sum3`,
  integer `sumi`) with `_bits`. Replaying the steps in order reproduces
  `final.value_bits` (`0x4043d9493c14617d`); `final.printf` is `%.6f`.
- U01d wrap branches: `wrap_plain` pins the saturating underlying draws
  from constructed state `[0, 4013241349, 777, 0, 888, 4028242508]`;
  `wrap_incprec` (wraps to `0x3e66888874000000`) and `wrap_both`
  (wraps to `0x3fefffffe977778c`) pin the first combined draw of each
  flag combination.

## Licence note

The numbers here are functional test outputs. The reference
implementation is free for personal/academic/non-commercial use;
contact P. L'Ecuyer for commercial licensing of the reference itself.
